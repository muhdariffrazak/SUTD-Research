//libaries and header files
#include <Arduino_FreeRTOS.h>
#include <FastLED.h>
#include <signallights.h>



//--------------------------------------------------
//object for signal lights
signallights A(125);


//--------------------------------------------------
// To handle task suspension/resumtion.
TaskHandle_t Handle_TaskBrakeLight;
TaskHandle_t Handle_TaskSerialRead;
TaskHandle_t Handle_TaskHeadLight;
TaskHandle_t Handle_TaskSignalLight;
TaskHandle_t Handle_TaskHazardLight;
TaskHandle_t Handle_TaskEStop;
TaskHandle_t Handle_TaskFeedback;


//--------------------------------------------------
// define two tasks for Blink & AnalogRead
void TaskBrakeLight( void *pvParameters );
void TaskSerialRead( void *pvParameters );
void TaskHeadLight( void *pvParameters );
void TaskSignalLight( void *pvParameters );
void TaskHazardLight( void *pvParameters );
void TaskEStop( void *pvParameters );
void TaskFeedback( void *pvParameters );


//--------------------------------------------------
//Flags to trigger tasks 
bool BrakeOn=false;// output as feedback
bool DayLight=false;// output as feedback
bool LightOn=false;// output as feedback                                    
bool change=false;
bool lastState=false;

bool SignalRight=false;// output as feedback
bool SignalRightHard=false;// output as feedback
bool SignalLeft=false;// output as feedback
bool SignalLeftHard=false;// output as feedback
bool HazardLight=false;// output as feedback
bool Beacon=false;// output as feedback

int BrakePin=6;
int DayPin=7;
int NightPin=13;
int BeaconPin=12;

char command=0;


//--------------------------------------------------
// the setup function runs once when you press reset or power the board
void setup() {
  // initialize serial communication at 9600 bits per second:
  Serial.begin(9600);
  while (!Serial) {
    ; // wait for serial port to connect. Needed for native USB, on LEONARDO, MICRO, YUN, and other 32u4 based boards.
  }


//--------------------------------------------------
  // Tasks are created here.
  xTaskCreate(
    TaskSerialRead
    ,  "SerialRead"
    ,  100  // Stack size
    ,  NULL
    ,  1  // Priority
    ,  &Handle_TaskSerialRead );

  xTaskCreate(
    TaskFeedback
    ,  "Feedback"
    ,  100  // Stack size
    ,  NULL
    ,  1  // Priority
    ,  &Handle_TaskFeedback );

  xTaskCreate(
    TaskBrakeLight
    ,  "BrakeLight"   // A name just for humans
    ,  100  // This stack size can be checked & adjusted by reading the Stack Highwater
    ,  NULL
    ,  3  // Priority, with 3 (configMAX_PRIORITIES - 1) being the highest, and 0 being the lowest.
    ,  &Handle_TaskBrakeLight );
  xTaskCreate(
    TaskHeadLight
    ,  "HeadLight"
    ,  100  // Stack size
    ,  NULL
    ,  2  // Priority
    ,  &Handle_TaskHeadLight );
  xTaskCreate(
    TaskSignalLight
    ,  "SignalLight"
    ,  100  // Stack size
    ,  NULL
    ,  2  // Priority
    ,  &Handle_TaskSignalLight );
  xTaskCreate(
    TaskHazardLight
    ,  "HazardLight"
    ,  100  // Stack size
    ,  NULL
    ,  2  // Priority
    ,  &Handle_TaskHazardLight );
  xTaskCreate(
    TaskEStop
    ,  "EStop"
    ,  100  // Stack size
    ,  NULL
    ,  2  // Priority
    ,  &Handle_TaskEStop );
  // Now the task scheduler, which takes over control of scheduling individual tasks, is automatically started.
}


//--------------------------------------------------
void loop()
{
  // Empty. Things are done in Tasks.
}


//--------------------------------------------------
//Task definitions


//--------------------------------------------------
//Task for serial read
void TaskSerialRead(void *pvParameters)  // Task to serial read and set flags
{
  (void) pvParameters;

  for (;;)//Task loop
  {
    if(Serial.available()>0){
      byte command = Serial.read();
      if(bitRead(command,0) == 1){
        BrakeOn=true;
        vTaskResume(Handle_TaskBrakeLight);
        vTaskDelay(50/portTICK_PERIOD_MS);
        change=!change;
        vTaskResume(Handle_TaskFeedback);
        vTaskDelay(50/portTICK_PERIOD_MS);
      }
      if (bitRead(command,0) == 0){
        BrakeOn=false;
        vTaskResume(Handle_TaskBrakeLight);
        vTaskDelay(50/portTICK_PERIOD_MS);
        change=!change;
        vTaskResume(Handle_TaskFeedback);
        vTaskDelay(50/portTICK_PERIOD_MS);
      }
      
  
}
}
}


void TaskFeedback(void *pvParameters)  // Task to serial read and set flags
{
  (void) pvParameters;

  for (;;)//Task loop
  {
    if (change!=lastState) {
      lastState=change;
      Serial.println("---------------------------");
      Serial.println("Change");
      vTaskDelay( 50 / portTICK_PERIOD_MS ); // wait for one second

      // Changed (or first), clear first and remember new state
    }
    else {
      Serial.println("not changed");
      vTaskDelay( 50 / portTICK_PERIOD_MS ); // wait for one second
    }
    vTaskSuspend(NULL);
  }
}

//--------------------------------------------------
//Task for brake light
void TaskBrakeLight(void *pvParameters)  // This is a task.
{
  (void) pvParameters;

  pinMode(BrakePin, OUTPUT);
  analogWrite(BrakePin,0);    // turn the LED off by making the voltage LOW

  for (;;) // A Task shall never return or exit.
  {
    if(BrakeOn==true){
    analogWrite(BrakePin,255);   // turn the LED on (HIGH is the voltage level)
    vTaskDelay( 50 / portTICK_PERIOD_MS ); // wait for one second
    }
    else{
    analogWrite(BrakePin,0);    // turn the LED off by making the voltage LOW
    vTaskDelay( 50 / portTICK_PERIOD_MS ); // wait for one second
    }
    vTaskSuspend(NULL);
  }
}


//--------------------------------------------------
//Task for head light
void TaskHeadLight(void *pvParameters)  // Task to control headlight
{
  (void) pvParameters;

  pinMode(DayPin, OUTPUT);
  pinMode(NightPin, OUTPUT);
  analogWrite(DayPin,0);    // turn the LED off by making the voltage LOW
  analogWrite(NightPin,0);  
  
  for (;;) // A Task shall never return or exit.
  {
    if((DayLight==true)){
    analogWrite(DayPin,255);   // turn the LED on (HIGH is the voltage level)
    vTaskDelay( 50 / portTICK_PERIOD_MS ); // wait for one second
    }
    else if((DayLight==false)){
      analogWrite(DayPin,0);
      vTaskDelay( 50 / portTICK_PERIOD_MS ); // wait for one second
      }
    else{
      analogWrite(NightPin,0); 
      vTaskDelay( 50 / portTICK_PERIOD_MS ); // wait for one second
      analogWrite(DayPin,0); // turn the LED off by making the voltage LOW
      vTaskDelay( 50 / portTICK_PERIOD_MS ); // wait for one second
    }
    vTaskSuspend(NULL);
  }
}


//--------------------------------------------------
//Task for signal light
void TaskSignalLight(void *pvParameters)  // Task to control signal light
{
  (void) pvParameters;
  A.init_signallights();

  for (;;)//Loop for the signal light
  {
    if ((SignalRight==true)&&(SignalRightHard==false)){
      A.RightSoftSignalOn();
      SignalRight=false;
      SignalRightHard=false;
      vTaskSuspend(NULL);
    }
    else if ((SignalRight==true)&&(SignalRightHard==true)){
      A.RightHardSignalOn();
      }


    else if ((SignalLeft==true)&&(SignalLeftHard==false)){
      A.LeftSoftSignalOn();
      SignalLeft=false; 
      SignalLeftHard=false;
      vTaskSuspend(NULL);
      }
    else if ((SignalLeft==true)&&(SignalLeftHard==true)){
      A.LeftHardSignalOn();
      }
    else{
      A.signalOff();
      vTaskSuspend(NULL);
    }
    vTaskDelay( 100 / portTICK_PERIOD_MS );
  }
}


//--------------------------------------------------
//Task for hazard light
void TaskHazardLight(void *pvParameters)  // Task to control hazard light
{
  (void) pvParameters;
  A.init_signallights();

  for (;;)//Loop for the hazard light
  {
    if (HazardLight==true){
      A.HazardLightOn();
    }
    else{
      A.signalOff();
      vTaskSuspend(NULL);
    }
    vTaskDelay( 100 / portTICK_PERIOD_MS );
  }
}

//--------------------------------------------------
//Task for Emergency Stop
void TaskEStop(void *pvParameters)  // Task to control hazard light
{
  (void) pvParameters;
  A.init_signallights();

  for (;;)//Loop for the hazard light
  {
    if ((HazardLight==true)&&(Beacon==true)){
      A.HazardLightOn();
      analogWrite(BeaconPin,255);
    }
    else{
      A.signalOff();
      analogWrite(BeaconPin,0);
      vTaskSuspend(NULL);
    }
    vTaskDelay( 100 / portTICK_PERIOD_MS );
  }
}
