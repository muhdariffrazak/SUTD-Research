#ifndef LinearActuator_h
#define LinearActuator_h

#include <Arduino.h>
//Type in class definition here

class LinearActuator
{
public:
//constructor
LinearActuator(uint8_t In1,uint8_t In2,  String AnalogPin, const char* side, int maxExt);

//static member
static int numOfMotors;


//class functions
void Extend();
void Contract();
void SafeStart();
void ExtendDistance()
String getPosition();



//Encapsulating motor data in private
private:
uint8_t In1;
uint8_t In2;
string AnalogPin;
char side;
int maxExt;

};