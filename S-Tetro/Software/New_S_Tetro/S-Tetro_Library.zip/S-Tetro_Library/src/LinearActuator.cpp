#include "LinearActuator.h"
#include <Arduino.h>

//Constructor
LinearActuator::LinearActuator(uint8_t In1,uint8_t In2,  String AnalogPin, const char* side, int maxExt);
{
  this->MotorID = MotorID;
  this->MotorBaud = MotorBaud;
  this->Protocol = Protocol; 
  this->side;
  this->maxExt;
}


void LinearActuator::Extend(){      
  int sensorValue = analogRead(A0);
  if (sensorValue >= 1000){
    continue;
  }
  else{
    while (sensorValue <= 1000){
      digitalWrite(in1, LOW);
      digitalWrite(in2, HIGH);
      sensorValue = analogRead(A0);
    }
    digitalWrite(in1, LOW);
    digitalWrite(in2, LOW);
  }
 }


void LinearActuator::Contract(){   
  int sensorValue = analogRead(A0);
  if (sensorValue <= 15 ){
    continue;
  }
  else{
    while (sensorValue  >= 15){
      digitalWrite(in1, HIGH);
      digitalWrite(in2, LOW);
      sensorValue = analogRead(A0);
    }
    digitalWrite(in1, LOW);
    digitalWrite(in2, LOW);
  }
 }



void LinearActuator::SafeStart(){
  int sensorValue = analogRead(A0);
  if (sensorValue != 15){
    Contract();
  }
}


void LinearActuator::ExtendDIstance(int DistanceInCM){
  int DistToExt=(maxExt/1000)*DistanceInCM;
  int sensorValue = analogRead(A0);
  while (sensorValue <= DistanceInCM){
    digitalWrite(in1, LOW);
    digitalWrite(in2, HIGH);
    sensorValue = analogRead(A0);
  }
  digitalWrite(in1, LOW);
  digitalWrite(in2, LOW);
}


String LinearActuator::getPosition(){
  String send;
  send="Actuator" +  String(side) + "is at " + String( sensorValue = analogRead(A0););
  return send;
}