#ifndef DynamixelCleaningMotor_h
#define DynamixelCleaningMotor_h
#include <Arduino.h>
#include <DynamixelShield.h>
#include <SoftwareSerial.h>

//Type in class definition here
class DynamixelCleaningMotor: public DynamixelShield 
{
public:
//constructor
DynamixelCleaningMotor(uint8_t MotorID, unsigned long MotorBaud, float Protocol, const char* side);

//static member
static int numOfMotors;


//class functions
void initCleaningMotor();
void cleanMode();
void climbMode();
void SafeStartMotor();
void moveMotor(int angle);
static int ShowNumOfMotors();
String getPosition();


//Encapsulating motor data in private
private:
uint8_t MotorID;
unsigned long MotorBaud;
float Protocol;
float angle;
char side;

};




//End of class definition



#endif