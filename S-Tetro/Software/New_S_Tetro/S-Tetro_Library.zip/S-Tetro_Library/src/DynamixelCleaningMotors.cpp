#include "DynamixelCleaningMotor.h"
#include <Arduino.h>
#include <DynamixelShield.h>
#include <Dynamixel2Arduino.h>


//Constructor
DynamixelCleaningMotor::DynamixelCleaningMotor(uint8_t MotorID, unsigned long MotorBaud, float Protocol, const char* side)
{
  this->MotorID = MotorID;
  this->MotorBaud = MotorBaud;
  this->Protocol = Protocol; 
  this->side;
}


//Intialise Dynamixel Protocol, Baud Rate and Motor ID
void DynamixelCleaningMotor::initCleaningMotor()
{
  
  Dynamixel2Arduino::begin(MotorBaud);
  Dynamixel2Arduino::setPortProtocolVersion(Protocol);
  Dynamixel2Arduino::ping(MotorID);


  DynamixelCleaningMotor::torqueOff(MotorID);
  DynamixelCleaningMotor::setOperatingMode(MotorID, OP_POSITION);
  DynamixelCleaningMotor::torqueOn(MotorID);
}



// Turns the pad horizontaly to clean the staircase step
void DynamixelCleaningMotor::cleanMode()
{

  // Set Goal Position in DEGREE value
  DynamixelCleaningMotor::setGoalPosition(MotorID, 150.0, UNIT_DEGREE);
  delay(1000);
}



//Turns the pad vertically to climb stairs
void DynamixelCleaningMotor::climbMode()
{

  // Set Goal Position in DEGREE value
  DynamixelCleaningMotor::setGoalPosition(MotorID, 240, UNIT_DEGREE);
  delay(1000);
}




// Custom Function to start the brush in a safe position.
void DynamixelCleaningMotor::SafeStartMotor()
{
  if (250> DynamixelCleaningMotor::getPresentPosition(MotorID, UNIT_DEGREE) <= 240.0)
  {
    delay(1000);
  }
  else
  {
    DynamixelCleaningMotor::climbMode(); // Brings the pad into a safe position 
  }
}



//Custom Function to bring the claw to a user defined position
void DynamixelCleaningMotor::moveMotor(int position)
{
  DynamixelCleaningMotor::setGoalPosition(MotorID, position);
  delay(1000);
}



//Function to return position
String DynamixelCleaningMotor::getPosition()
{
  String send;
  send="Cleaning Motor " +  String(MotorID) + "is at " + String(DynamixelCleaningMotor::getPresentPosition(MotorID, UNIT_DEGREE));
  return send;
}




/*static void ShowNumOfMotors()
{
  return DynamixelCleaningMotor::numOfMotors;
}*/